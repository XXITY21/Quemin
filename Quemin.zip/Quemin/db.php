<?php
$host = "localhost";
$database = "db_quemin";
$charset = "UTF-8";
$user = "root";
$password = "";
$pdo = new PDO("mysql:host=$host;dbname=$database; char set=$charset ", $user, $password);

?>
